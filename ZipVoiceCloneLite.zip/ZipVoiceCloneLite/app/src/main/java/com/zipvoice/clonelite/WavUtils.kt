package com.zipvoice.clonelite

import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder

data class WavData(val samples: FloatArray, val sampleRate: Int)

object WavUtils {

    fun parseWav(input: InputStream): WavData {
        val bytes = ByteArrayOutputStream().also { input.copyTo(it) }.toByteArray()
        val buf = ByteBuffer.wrap(bytes).order(ByteOrder.LITTLE_ENDIAN)

        require(bytes.size >= 12) { "File WAV terlalu kecil atau rusak" }
        require(tag(bytes, 0) == "RIFF" && tag(bytes, 8) == "WAVE") {
            "Bukan file WAV valid (header RIFF/WAVE tidak ditemukan)"
        }

        var pos = 12
        var sampleRate = -1
        var numChannels = -1
        var bitsPerSample = -1
        var audioFormat = -1
        var dataOffset = -1
        var dataLength = -1

        while (pos + 8 <= bytes.size) {
            val id = tag(bytes, pos)
            val size = buf.getInt(pos + 4).toLong() and 0xFFFFFFFFL
            val body = pos + 8
            when (id) {
                "fmt " -> {
                    require(size >= 16 && body + 16 <= bytes.size) { "Chunk 'fmt ' rusak" }
                    audioFormat = buf.getShort(body).toInt() and 0xFFFF
                    numChannels = buf.getShort(body + 2).toInt() and 0xFFFF
                    sampleRate = buf.getInt(body + 4)
                    bitsPerSample = buf.getShort(body + 14).toInt() and 0xFFFF
                }
                "data" -> {
                    dataOffset = body
                    dataLength = minOf(size, (bytes.size - body).toLong()).toInt()
                }
            }
            if (dataOffset >= 0 && sampleRate > 0) break
            val next = body.toLong() + size + (size and 1L)
            if (next > bytes.size) break
            pos = next.toInt()
        }

        require(sampleRate > 0 && numChannels > 0) { "Chunk 'fmt ' tidak ditemukan" }
        require(dataOffset >= 0) { "Chunk 'data' tidak ditemukan" }
        require(bitsPerSample == 16) {
            "Hanya WAV PCM 16-bit yang didukung (file ini $bitsPerSample-bit)"
        }
        require(audioFormat == 1 || audioFormat == 0xFFFE) {
            "Hanya WAV PCM yang didukung (format audio = $audioFormat)"
        }

        val frameSize = numChannels * 2
        val frames = dataLength / frameSize
        val samples = FloatArray(frames)
        for (i in 0 until frames) {
            val s = buf.getShort(dataOffset + i * frameSize).toInt() // channel pertama
            samples[i] = s / 32768f
        }
        return WavData(samples, sampleRate)
    }

    private fun tag(b: ByteArray, off: Int) = String(b, off, 4, Charsets.US_ASCII)
}
