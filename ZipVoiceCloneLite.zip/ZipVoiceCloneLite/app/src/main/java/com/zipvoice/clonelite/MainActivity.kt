package com.zipvoice.clonelite

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.k2fsa.sherpa.onnx.GenerationConfig
import com.k2fsa.sherpa.onnx.OfflineTts
import com.k2fsa.sherpa.onnx.OfflineTtsConfig
import com.k2fsa.sherpa.onnx.OfflineTtsModelConfig
import com.k2fsa.sherpa.onnx.OfflineTtsZipVoiceModelConfig
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class MainActivity : AppCompatActivity() {

    private var wavData: WavData? = null
    private lateinit var tvRefName: TextView
    private lateinit var etText: EditText
    private lateinit var etRefTranscript: EditText
    private lateinit var btnGenerate: Button
    private lateinit var btnPlay: Button
    private lateinit var progressBar: ProgressBar

    // Hasil generate terakhir
    private var audioSamples: FloatArray? = null
    private var audioSampleRate: Int = 0

    // Pemutaran
    private val trackLock = Any()
    private var audioTrack: AudioTrack? = null

    // Lazy init; hanya diakses dari Dispatchers.Default (bukan main thread)
    private val tts: OfflineTts by lazy {
        val config = OfflineTtsConfig(
            model = OfflineTtsModelConfig(
                zipvoice = OfflineTtsZipVoiceModelConfig(
                    tokens = "zipvoice/tokens.txt",
                    encoder = "zipvoice/encoder.int8.onnx",
                    decoder = "zipvoice/decoder.int8.onnx",
                    vocoder = "zipvoice/vocoder.onnx",
                    lexicon = "zipvoice/lexicon.txt"
                ),
                numThreads = 2
            )
        )
        OfflineTts(assetManager = assets, config = config)
    }

    private val pickWav = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) handleRef(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvRefName = findViewById(R.id.tvRefName)
        etText = findViewById(R.id.etText)
        etRefTranscript = findViewById(R.id.etRefTranscript)
        btnGenerate = findViewById(R.id.btnGenerate)
        btnPlay = findViewById(R.id.btnPlay)
        progressBar = findViewById(R.id.progressBar)

        findViewById<Button>(R.id.btnPickRef).setOnClickListener {
            pickWav.launch(arrayOf("audio/wav", "audio/x-wav"))
        }
        btnGenerate.setOnClickListener { onGenerate() }
        btnPlay.setOnClickListener { onPlay() }
    }

    override fun onDestroy() {
        super.onDestroy()
        stopPlayback()
    }

    private fun onGenerate() {
        val wav = wavData
        val refText = etRefTranscript.text.toString()
        val text = etText.text.toString()
        when {
            wav == null -> return toast("Pilih audio referensi WAV dulu")
            refText.isBlank() -> return toast("Transkrip referensi kosong")
            text.isBlank() -> return toast("Teks kosong")
            text.length > 200 -> return toast("Teks maksimal 200 karakter")
        }
        wav!!

        progressBar.visibility = View.VISIBLE
        btnGenerate.isEnabled = false

        CoroutineScope(Dispatchers.Default).launch {
            try {
                val genConfig = GenerationConfig(
                    referenceAudio = wav.samples,
                    referenceSampleRate = wav.sampleRate,
                    referenceText = refText,
                    numSteps = 4
                )
                val audio = tts.generateWithConfig(text, genConfig)
                withContext(Dispatchers.Main) {
                    audioSamples = audio.samples
                    audioSampleRate = audio.sampleRate
                    progressBar.visibility = View.GONE
                    btnGenerate.isEnabled = true
                    btnPlay.isEnabled = true
                }
            } catch (t: Throwable) {
                withContext(Dispatchers.Main) {
                    progressBar.visibility = View.GONE
                    btnGenerate.isEnabled = true
                    Toast.makeText(
                        this@MainActivity,
                        "Gagal generate: ${t.message ?: t.javaClass.simpleName}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }
    }

    private fun onPlay() {
        val samples = audioSamples
        val rate = audioSampleRate
        if (samples == null || samples.isEmpty() || rate <= 0) {
            toast("Belum ada audio hasil generate")
            return
        }
        stopPlayback()
        Thread {
            try {
                val track = AudioTrack.Builder()
                    .setAudioAttributes(
                        AudioAttributes.Builder()
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                            .build()
                    )
                    .setAudioFormat(
                        AudioFormat.Builder()
                            .setEncoding(AudioFormat.ENCODING_PCM_FLOAT)
                            .setSampleRate(rate)
                            .setChannelMask(AudioFormat.CHANNEL_OUT_MONO)
                            .build()
                    )
                    .setBufferSizeInBytes(samples.size * 4)
                    .setTransferMode(AudioTrack.MODE_STATIC)
                    .build()
                synchronized(trackLock) { audioTrack = track }
                track.write(samples, 0, samples.size, AudioTrack.WRITE_BLOCKING)
                track.play()
            } catch (t: Throwable) {
                runOnUiThread {
                    Toast.makeText(
                        this,
                        "Gagal memutar: ${t.message ?: t.javaClass.simpleName}",
                        Toast.LENGTH_LONG
                    ).show()
                }
            }
        }.start()
    }

    private fun stopPlayback() {
        synchronized(trackLock) {
            audioTrack?.let {
                try {
                    it.stop()
                } catch (_: Exception) {
                }
                it.release()
            }
            audioTrack = null
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }

    private fun handleRef(uri: Uri) {
        try {
            val name = queryName(uri) ?: "referensi.wav"
            val cached = File(cacheDir, "ref_audio.wav")
            contentResolver.openInputStream(uri)?.use { input ->
                cached.outputStream().use { out -> input.copyTo(out) }
            } ?: throw IllegalStateException("Tidak bisa membuka file")

            wavData = cached.inputStream().use { WavUtils.parseWav(it) }
            tvRefName.text = name
        } catch (e: Exception) {
            wavData = null
            tvRefName.text = "Belum ada file"
            Toast.makeText(this, e.message ?: "Gagal membaca WAV", Toast.LENGTH_LONG).show()
        }
    }

    private fun queryName(uri: Uri): String? =
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
}
