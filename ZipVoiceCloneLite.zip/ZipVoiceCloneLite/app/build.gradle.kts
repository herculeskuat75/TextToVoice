plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zipvoice.clonelite"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.zipvoice.clonelite"
        minSdk = 26
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    androidResources {
        noCompress += listOf("onnx", "bin", "txt", "espeak-ng-data")
    }
}

dependencies {
    implementation("com.github.k2-fsa:sherpa-onnx:v1.13.5")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.8.1")
    // Wajib agar AppCompatActivity (spesifikasi #7) bisa dikompilasi
    implementation("androidx.appcompat:appcompat:1.6.1")
}
